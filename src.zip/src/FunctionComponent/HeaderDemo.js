/*
Function Component (StateLess Component)
*/

function HeaderDemo(){
    return (
        <div style={{backgroundColor:'teal'}}>
            <h1>Header Demo</h1>
            <h1>Title</h1>
        </div>
    )
}

export default HeaderDemo;