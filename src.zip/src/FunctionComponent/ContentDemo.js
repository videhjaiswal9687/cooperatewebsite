import React from 'react';

export const ContentDemo = () => {
    return <div style={{backgroundColor:'black',color:'white',height:500}}>
        <h1>React</h1>
        <p>
            A JavaScript library for building user interfaces
        </p>
        <button style={{backgroundColor:'teal',color:'white'}}>Get Started</button>
    </div>;
};
