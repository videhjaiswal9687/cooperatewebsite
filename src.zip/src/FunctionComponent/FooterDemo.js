import React from 'react';

export const FooterDemo = () => {
  return <div style={{backgroundColor:'orange',color:'white',height:100}}>
      <p>Copyright © 2022 Meta Platforms, Inc.</p>
  </div>;
};
