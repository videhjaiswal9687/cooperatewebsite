export const COVAXIN = "COVAXIN"
export const COVISHIELD = "COVISHIELD"