import React, { Component } from 'react'

export default class Email extends Component {
    render() {
        return (
            <div>
                <h1>Email Component</h1>
                <h1>abc@gmail.com</h1>
            </div>
        )
    }
}
