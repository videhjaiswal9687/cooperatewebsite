import React, { Component } from 'react'

export default class Profile extends Component {
    render() {
        return (
            <div>
                <h1>Profile Component</h1>
                <a href='https://www.google.com/'><h1>Google</h1></a>
            </div>
        )
    }
}
